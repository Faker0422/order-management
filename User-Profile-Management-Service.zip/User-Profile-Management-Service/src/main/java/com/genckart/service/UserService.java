package com.genckart.service;

import com.genckart.dto.UserAuthDTO;
import com.genckart.dto.UserDTO;

public interface UserService {
    UserDTO registerUser(UserDTO userDTO);
    UserDTO updateUser(UserDTO userDTO);
    UserDTO getUserById(Integer userId);
    UserAuthDTO getUserByName(String userName);
    UserAuthDTO getUserByEmail(String email);
}
