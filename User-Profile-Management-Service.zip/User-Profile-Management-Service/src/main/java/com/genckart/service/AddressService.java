package com.genckart.service;

import com.genckart.dto.AddressDTO;

public interface AddressService {
    AddressDTO saveAddress(AddressDTO addressDTO);
    AddressDTO updateAddress(AddressDTO addressDTO);
    AddressDTO getAddressById(int addressId);
}
