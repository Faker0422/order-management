package com.genckart.service;
import com.genckart.dto.AddressDTO;
import com.genckart.entity.Address;
import com.genckart.entity.User;
import com.genckart.exception.AddressNotFoundException;
import com.genckart.exception.UserNotFoundException;
import com.genckart.repository.AddressRepository;
import com.genckart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AddressServiceImpl implements AddressService {

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public AddressDTO saveAddress(AddressDTO addressDTO) {
        Address address = convertToEntity(addressDTO);
        Address savedAddress = addressRepository.save(address);
        return convertToDTO(savedAddress);
    }

    @Override
    public AddressDTO updateAddress(AddressDTO addressDTO) {
        Address address = convertToEntity(addressDTO);
        Address updatedAddress = addressRepository.save(address);
        return convertToDTO(updatedAddress);
    }

    @Override
    public AddressDTO getAddressById(int addressId) {
        Address address = addressRepository.findById(addressId).orElseThrow(() -> new AddressNotFoundException("Address not found"));
        return convertToDTO(address);
    }

    private Address convertToEntity(AddressDTO addressDTO) {
        Address address = new Address();
        address.setAddressId(addressDTO.getAddressId());
        address.setStreet(addressDTO.getStreet());
        address.setCity(addressDTO.getCity());
        address.setState(addressDTO.getState());
        address.setPostalCode(addressDTO.getPostalCode());
        address.setCountry(addressDTO.getCountry());

        // Set the user
        User user = userRepository.findById(addressDTO.getUserId())
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + addressDTO.getUserId()));
        address.setUser(user);

        return address;
    }

    private AddressDTO convertToDTO(Address address) {
        AddressDTO addressDTO = new AddressDTO();
        addressDTO.setAddressId(address.getAddressId());
        addressDTO.setStreet(address.getStreet());
        addressDTO.setCity(address.getCity());
        addressDTO.setState(address.getState());
        addressDTO.setPostalCode(address.getPostalCode());
        addressDTO.setCountry(address.getCountry());
        addressDTO.setUserId(address.getUser().getUserId());
        return addressDTO;
    }
}