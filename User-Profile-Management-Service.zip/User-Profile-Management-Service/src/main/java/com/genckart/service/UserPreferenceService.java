package com.genckart.service;

import com.genckart.dto.UserPreferenceDTO;

public interface UserPreferenceService {
    UserPreferenceDTO saveUserPreference(UserPreferenceDTO userPreferenceDTO);
}
