package com.genckart.service;

import com.genckart.dto.UserPreferenceDTO;
import com.genckart.entity.User;
import com.genckart.entity.UserPreference;
import com.genckart.exception.UserNotFoundException;
import com.genckart.repository.UserPreferenceRepository;
import com.genckart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserPreferenceServiceImpl implements UserPreferenceService {

    @Autowired
    private UserPreferenceRepository userPreferenceRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserPreferenceDTO saveUserPreference(UserPreferenceDTO userPreferenceDTO) {
        UserPreference userPreference = convertToEntity(userPreferenceDTO);
        UserPreference savedUserPreference = userPreferenceRepository.save(userPreference);
        return convertToDTO(savedUserPreference);
    }

    private UserPreference convertToEntity(UserPreferenceDTO userPreferenceDTO) {
        UserPreference userPreference = new UserPreference();
        userPreference.setPreferenceId(userPreferenceDTO.getPreferenceId());
        userPreference.setCategoryId(userPreferenceDTO.getCategoryId());
        userPreference.setBrand(userPreferenceDTO.getBrand());
        userPreference.setMinPrice(userPreferenceDTO.getMinPrice());
        userPreference.setMaxPrice(userPreferenceDTO.getMaxPrice());
        userPreference.setGender(userPreferenceDTO.getGender());

        // Set the user
        User user = userRepository.findById(userPreferenceDTO.getUserId())
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userPreferenceDTO.getUserId()));
        userPreference.setUser(user);

        return userPreference;
    }

    private UserPreferenceDTO convertToDTO(UserPreference userPreference) {
        UserPreferenceDTO userPreferenceDTO = new UserPreferenceDTO();
        userPreferenceDTO.setPreferenceId(userPreference.getPreferenceId());
        userPreferenceDTO.setCategoryId(userPreference.getCategoryId());
        userPreferenceDTO.setBrand(userPreference.getBrand());
        userPreferenceDTO.setMinPrice(userPreference.getMinPrice());
        userPreferenceDTO.setMaxPrice(userPreference.getMaxPrice());
        userPreferenceDTO.setGender(userPreference.getGender());
        userPreferenceDTO.setUserId(userPreference.getUser().getUserId());
        return userPreferenceDTO;
    }
}