package com.genckart.service;

import com.genckart.dto.UserAuthDTO;
import com.genckart.dto.UserDTO;
import com.genckart.entity.User;
import com.genckart.exception.UserNotFoundException;
import com.genckart.repository.UserRepository;
import com.genckart.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDTO registerUser(UserDTO userDTO) {
        User user = convertToEntity(userDTO);
        User savedUser = userRepository.save(user);
        return convertToDTO(savedUser);
    }

    @Override
    public UserDTO updateUser(UserDTO userDTO) {
        User existingUser = userRepository.findById(userDTO.getUserId())
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userDTO.getUserId()));

        existingUser.setName(userDTO.getName());
        existingUser.setEmail(userDTO.getEmail());
        existingUser.setPhoneNumber(userDTO.getPhoneNumber());
        existingUser.setPasswordHash(userDTO.getPasswordHash());
        existingUser.setRole(userDTO.getRole());

        User updatedUser = userRepository.save(existingUser);
        return convertToDTO(updatedUser);
    }

    @Override
    public UserDTO getUserById(Integer userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new UserNotFoundException("User not found"));
        return convertToDTO(user);
    }

    @Override
    public UserAuthDTO getUserByName(String userName) {
        User user = userRepository.findByName(userName).orElseThrow(() -> new UserNotFoundException("User not found with name: " + userName));
        return convertToAuthDTO(user);
    }

    @Override
    public UserAuthDTO getUserByEmail(String email) {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new UserNotFoundException("User not found with email: " + email));
        return convertToAuthDTO(user);
    }

    private User convertToEntity(UserDTO userDTO) {
        User user = new User();
        user.setUserId(userDTO.getUserId());
        user.setName(userDTO.getName());
        user.setEmail(userDTO.getEmail());
        user.setPhoneNumber(userDTO.getPhoneNumber());
        user.setPasswordHash(userDTO.getPasswordHash());
        user.setRole(userDTO.getRole());
        return user;
    }

    private UserDTO convertToDTO(User user) {
        UserDTO userDTO = new UserDTO();
        userDTO.setUserId(user.getUserId());
        userDTO.setName(user.getName());
        userDTO.setEmail(user.getEmail());
        userDTO.setPhoneNumber(user.getPhoneNumber());
        userDTO.setPasswordHash(user.getPasswordHash());
        userDTO.setRole(user.getRole());
        return userDTO;
    }

    private UserAuthDTO convertToAuthDTO(User user) {
        UserAuthDTO userAuthDTO = new UserAuthDTO();
        userAuthDTO.setUserId(user.getUserId());
        userAuthDTO.setUserName(user.getName());
        userAuthDTO.setEmail(user.getEmail());
        userAuthDTO.setRole(user.getRole());
        return userAuthDTO;
    }
}