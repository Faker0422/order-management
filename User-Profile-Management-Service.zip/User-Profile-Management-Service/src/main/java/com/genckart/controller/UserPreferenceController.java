package com.genckart.controller;

import com.genckart.dto.UserPreferenceDTO;
import com.genckart.service.UserPreferenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user/preferences")
public class UserPreferenceController {

    @Autowired
    private UserPreferenceService userPreferenceService;

    @PostMapping
    public ResponseEntity<UserPreferenceDTO> saveUserPreference(@RequestBody UserPreferenceDTO userPreferenceDTO) {
        UserPreferenceDTO savedPreference = userPreferenceService.saveUserPreference(userPreferenceDTO);
        return new ResponseEntity<>(savedPreference, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<UserPreferenceDTO> updateUserPreference(@RequestBody UserPreferenceDTO userPreferenceDTO) {
        UserPreferenceDTO updatedPreference = userPreferenceService.saveUserPreference(userPreferenceDTO);
        return new ResponseEntity<>(updatedPreference, HttpStatus.OK);
    }
}