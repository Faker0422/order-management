package com.genckart.clients;

import com.genckart.dto.UserPreferenceDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "user-preference-service")
public interface UserPreferenceClient {

    @PostMapping("/user/preferences")
    UserPreferenceDTO saveUserPreference(@RequestBody UserPreferenceDTO userPreferenceDTO);

    @PutMapping("/user/preferences")
    UserPreferenceDTO updateUserPreference(@RequestBody UserPreferenceDTO userPreferenceDTO);
}
