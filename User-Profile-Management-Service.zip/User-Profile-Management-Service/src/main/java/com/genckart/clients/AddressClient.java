package com.genckart.clients;

import com.genckart.dto.AddressDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "address-service")
public interface AddressClient {

    @PostMapping("/user/addresses")
    AddressDTO saveAddress(@RequestBody AddressDTO addressDTO);

    @PutMapping("/user/addresses/{id}")
    AddressDTO updateAddress(@PathVariable int id, @RequestBody AddressDTO addressDTO);

    @GetMapping("/user/addresses/{id}")
    AddressDTO getAddressById(@PathVariable int id);
}
