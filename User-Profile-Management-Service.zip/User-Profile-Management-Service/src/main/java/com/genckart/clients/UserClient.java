package com.genckart.clients;

import com.genckart.dto.UserDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "user-service")
public interface UserClient {

    @PostMapping("/user/register")
    UserDTO registerUser(@RequestBody UserDTO userDTO);

    @PutMapping("/user/profile")
    UserDTO updateUser(@RequestBody UserDTO userDTO);

    @GetMapping("/user/profile/{id}")
    UserDTO getUserById(@PathVariable Integer id);
}
