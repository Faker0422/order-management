package com.genckart.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserPreferenceDTO {
    private Integer preferenceId;
    private Integer userId;
    private Integer categoryId;
    private String brand;
    private Double minPrice;
    private Double maxPrice;
    private String gender;
}
