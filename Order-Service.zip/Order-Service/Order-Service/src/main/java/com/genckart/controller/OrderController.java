package com.genckart.controller;

import com.genckart.dto.OrderDTO;
import com.genckart.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/cart/{userId}")
    public ResponseEntity<OrderDTO> placeOrderFromCart(@PathVariable Integer userId) {
        OrderDTO savedOrder = orderService.placeOrderFromCart(userId);
        return new ResponseEntity<>(savedOrder, HttpStatus.CREATED);
    }

    @PostMapping("/product/{userId}/{productId}/{quantity}")
    public ResponseEntity<OrderDTO> placeOrderFromProductDetail(
            @PathVariable Integer userId,
            @PathVariable Integer productId,
            @PathVariable Integer quantity) {
        OrderDTO savedOrder = orderService.placeOrderFromProductDetail(userId, productId, quantity);
        return new ResponseEntity<>(savedOrder, HttpStatus.CREATED);
    }

    @GetMapping("/history/{userId}")
    public ResponseEntity<List<OrderDTO>> getOrderHistory(@PathVariable Integer userId) {
        List<OrderDTO> orders = orderService.getOrderHistory(userId);
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<OrderDTO> getOrderDetails(@PathVariable Integer orderId) {
        OrderDTO order = orderService.getOrderDetails(orderId);
        return new ResponseEntity<>(order, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{orderId}")
    public ResponseEntity<String> deleteOrder(@PathVariable Integer orderId){
        orderService.deleteOrder(orderId);
        return ResponseEntity.ok("Order deleted successfully");
    }
}
