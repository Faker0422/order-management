package com.genckart.service;

import com.genckart.dto.OrderDTO;
import java.util.List;

public interface OrderService {
    OrderDTO placeOrderFromCart(Integer userId);
    OrderDTO placeOrderFromProductDetail(Integer userId, Integer productId, Integer quantity);
    List<OrderDTO> getOrderHistory(Integer userId);
    OrderDTO getOrderDetails(Integer orderId);
    void deleteOrder(Integer orderId);
}