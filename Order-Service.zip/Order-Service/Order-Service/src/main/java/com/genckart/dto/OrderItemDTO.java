package com.genckart.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderItemDTO {
    private Integer orderItemId;
    private Integer productId;
    private String productName;
    private Integer quantity;
    private Double price;
    private Double discount;
    private Double finalPrice; // Computed price after discount
    private Timestamp createdAt;
}