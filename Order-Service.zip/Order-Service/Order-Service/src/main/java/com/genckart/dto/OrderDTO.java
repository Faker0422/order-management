package com.genckart.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderDTO {
    private Integer orderId;
    private Integer userId;
    private Double totalAmount;
    private String orderStatus;
    private Integer deliveryAddressId;
    private LocalDate deliveryDate;
    private Timestamp createdAt;
    private List<OrderItemDTO> orderItems; // List of order items
    private List<OrderHistoryDTO> orderHistory; // List of order history
}