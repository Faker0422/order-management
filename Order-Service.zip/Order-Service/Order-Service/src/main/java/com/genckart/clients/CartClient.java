package com.genckart.clients;

import com.genckart.dto.CartDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "CartService", url = "http://localhost:8080/cart")
public interface CartClient {
    @GetMapping("/user/{userId}")
    ResponseEntity<List<CartDTO>> getCartByUserId(@PathVariable Integer userId);
}