package com.genckart.exception;

import com.genckart.dto.StandardResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(OrderNotFoundException.class)
    public ResponseEntity<StandardResponseDTO<String>> handleOrderNotFoundException(OrderNotFoundException ex) {
    StandardResponseDTO<String> response = new StandardResponseDTO<>();
    response.setMessage("Order Not Found");
    response.setStatus("not found");

    return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }
}
