package com.genckart.dto;

import lombok.Data;

@Data
public class CartItemDTO {

    private Integer cartItemId;
    private Integer userId;
    private Integer productId;
    private Integer quantity;
    private String productName;
    private Double productPrice;
}
