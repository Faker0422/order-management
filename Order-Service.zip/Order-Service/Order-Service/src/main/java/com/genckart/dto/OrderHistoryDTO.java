package com.genckart.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderHistoryDTO {
    private Integer orderHistoryId;
    private Integer orderId;
    private Integer userId;
    private String orderStatus;
    @JsonIgnore
    private Timestamp statusChangedAt;
}