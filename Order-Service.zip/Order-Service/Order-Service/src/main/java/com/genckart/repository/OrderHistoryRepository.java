package com.genckart.repository;

import com.genckart.entity.OrderHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface OrderHistoryRepository extends JpaRepository<OrderHistory, Integer> {

    @Query("SELECT oh FROM OrderHistory oh WHERE oh.order.orderId = :orderId")
    List<OrderHistory> findByOrderId(Integer orderId);

    @Modifying
    @Transactional
    @Query("DELETE FROM OrderHistory oh WHERE oh.order.orderId = :orderId")
    void deleteByOrder_OrderId(@Param("orderId") Integer orderId);

}