package com.genckart.clients;

import com.genckart.dto.UserDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service", url = "http://localhost:8086/api/user")
public interface UserClient {
    @GetMapping("/profile/{id}")
    ResponseEntity<UserDTO> getUserById(@PathVariable Integer id);
}