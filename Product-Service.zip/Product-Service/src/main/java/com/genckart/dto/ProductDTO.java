package com.genckart.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductDTO {
    private Integer productId;
    private String name;
    private double newPrice;
    private double oldPrice;
    private String gender;
    private int quantity;
    private double rating;
    private String brand;
    private String popularity;
    private String color;
    private String description;
    private String image1;
    private String image2;
    private String image3;
    private double discount;
    private double highlightShippingFee;
    private String categoryName;
    private List<ReviewDTO> reviews;
    private List<ProductDTO> relatedProducts;
}