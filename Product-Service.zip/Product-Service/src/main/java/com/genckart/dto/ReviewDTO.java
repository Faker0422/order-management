package com.genckart.dto;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class ReviewDTO {
    private Integer reviewId;
    private Integer userId;
    private Integer productId;
    private int rating;
    private String reviewText;
    private UserDTO user;
    private Timestamp createdAt;// Include user details in the DTO
}
