package com.genckart.dto;

import lombok.Data;

@Data
public class CategoryDTO {
    private Integer categoryId;
    private String name;
    private Integer parentId;
}