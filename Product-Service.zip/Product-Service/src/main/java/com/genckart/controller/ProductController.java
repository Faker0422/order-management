package com.genckart.controller;

import com.genckart.dto.ProductDTO;
import com.genckart.exception.ResourceNotFoundException;
import com.genckart.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    private ResponseEntity<Object> createResponse(HttpStatus status, String message, Object data, String endpoint) {
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("status", status.value());
        body.put("message", message);
        body.put("data", data);
        body.put("endpoint", endpoint);
        return new ResponseEntity<>(body, status);
    }

    @GetMapping
    public ResponseEntity<Object> getAllProducts() {
        List<ProductDTO> products = productService.getAllProducts();
        if (products.isEmpty()) {
            return createResponse(HttpStatus.NOT_FOUND, "There are no products to display", null, "/api/products");
        }
        return createResponse(HttpStatus.OK, "Products retrieved successfully", products, "/api/products");
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> getProductById(@PathVariable Integer id) {
        try {
            ProductDTO product = productService.getProductById(id);
            return createResponse(HttpStatus.OK, "Product retrieved successfully", product, "/api/products/" + id);
        } catch (ResourceNotFoundException ex) {
            return createResponse(HttpStatus.NOT_FOUND, "Product with id " + id + " not found", null, "/api/products/" + id);
        }
    }

    @GetMapping("/search/{name}")
    public ResponseEntity<Object> getProductsByName(@PathVariable("name") String name) {
        List<ProductDTO> products = productService.getProductsByName(name);
        if (products.isEmpty()) {
            return createResponse(HttpStatus.NOT_FOUND, "Product with name " + name + " not found", null, "/api/products/search/" + name);
        }
        return createResponse(HttpStatus.OK, "Products retrieved successfully", products, "/api/products/search/" + name);
    }

    @PostMapping
    public ResponseEntity<Object> addProduct(@RequestBody ProductDTO productDTO) {
        try {
            ProductDTO savedProduct = productService.addProduct(productDTO);
            return createResponse(HttpStatus.CREATED, "Product added successfully", savedProduct, "/api/products");
        } catch (Exception ex) {
            return createResponse(HttpStatus.BAD_REQUEST, "Error: " + ex.getMessage(), null, "/api/products");
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateProductDetails(@PathVariable Integer id, @RequestBody ProductDTO productDTO) {
        try {
            ProductDTO updatedProduct = productService.updateProductDetails(id, productDTO);
            return createResponse(HttpStatus.OK, "Product updated successfully", updatedProduct, "/api/products/" + id);
        } catch (ResourceNotFoundException ex) {
            return createResponse(HttpStatus.NOT_FOUND, "Product with id " + id + " not found", null, "/api/products/" + id);
        } catch (Exception ex) {
            return createResponse(HttpStatus.BAD_REQUEST, "Error: " + ex.getMessage(), null, "/api/products/" + id);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteProduct(@PathVariable Integer id) {
        try {
            productService.deleteProduct(id);
            return createResponse(HttpStatus.OK, "Product deleted successfully", null, "/api/products/" + id);
        } catch (ResourceNotFoundException ex) {
            return createResponse(HttpStatus.NOT_FOUND, "Product with id " + id + " not found", null, "/api/products/" + id);
        }
    }

    @GetMapping("/{id}/related")
    public ResponseEntity<Object> getRelatedProducts(@PathVariable Integer id) {
        List<ProductDTO> relatedProducts = productService.getRelatedProducts(id);
        if (relatedProducts.isEmpty()) {
            return createResponse(HttpStatus.NOT_FOUND, "No related products found for product with id " + id, null, "/api/products/" + id + "/related");
        }
        return createResponse(HttpStatus.OK, "Related products retrieved successfully", relatedProducts, "/api/products/" + id + "/related");
    }

    @GetMapping("/related/category/{categoryName}")
    public ResponseEntity<Object> getRelatedProductsByCategoryName(@PathVariable("categoryName") String categoryName) {
        List<ProductDTO> relatedProducts = productService.getRelatedProductsByCategoryName(categoryName);
        if (relatedProducts.isEmpty()) {
            return createResponse(HttpStatus.NOT_FOUND, "No related products found for category " + categoryName, null, "/api/products/related/category/" + categoryName);
        }
        return createResponse(HttpStatus.OK, "Related products retrieved successfully", relatedProducts, "/api/products/related/category/" + categoryName);
    }

    @GetMapping("/{id}/details")
    public ResponseEntity<Object> getProductWithReviewsAndRelatedProducts(@PathVariable Integer id) {
        try {
            ProductDTO product = productService.getProductWithReviewsAndRelatedProducts(id);
            return createResponse(HttpStatus.OK, "Product details retrieved successfully", product, "/api/products/" + id + "/details");
        } catch (ResourceNotFoundException ex) {
            return createResponse(HttpStatus.NOT_FOUND, "Product with id " + id + " not found", null, "/api/products/" + id + "/details");
        }
    }
}