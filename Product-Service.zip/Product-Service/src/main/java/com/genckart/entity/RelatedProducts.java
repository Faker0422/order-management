package com.genckart.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="Related_Products")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class RelatedProducts {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer relatedId;

    @ManyToOne
    @JoinColumn(name="product_id", nullable=false)
    private Product product;

    @ManyToOne
    @JoinColumn(name="related_product_id", nullable=false)
    private Product relatedProducts;
}