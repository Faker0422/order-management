package com.genckart.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.sql.Timestamp;
import java.util.Set;

@Entity
@Table(name = "Products")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer productId;

    @Column(nullable = false)
    @NotNull(message = "Name cannot be null")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;

    @Column(nullable = false)
    @NotNull(message = "New price cannot be null")
    @Positive(message = "New price must be positive")
    private double newPrice;

    @Column(nullable = false)
    @NotNull(message = "Old price cannot be null")
    @Positive(message = "Old price must be positive")
    private double oldPrice;

    private String gender;

    @ManyToOne
    @JoinColumn(name = "category_name", nullable = false)
    @NotNull(message = "Category cannot be null")
    private Category category;

    @Min(value = 0, message = "Quantity cannot be negative")
    private int quantity;

    @Min(value = 0, message = "Rating cannot be negative")
    @Max(value = 5, message = "Rating cannot be more than 5")
    private double rating;

    private String brand;

    private String popularity;

    private String color;

    @Lob
    private String description;

    private String image1;

    private String image2;

    private String image3;

    @Min(value = 0, message = "Discount cannot be negative")
    private double discount;

    @Column(name = "highlights_shipping_fee")
    @Min(value = 0, message = "Highlight shipping fee cannot be negative")
    private double highlightShippingFee;

    @Column(updatable = false, insertable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;

    @OneToMany(mappedBy = "product", fetch = FetchType.LAZY)
    private Set<Review> reviews;

    @OneToMany(mappedBy = "product", fetch = FetchType.LAZY)
    private Set<RelatedProducts> relatedProducts;

//    @JsonIgnore
//    @OneToMany(mappedBy = "product")
//    private Set<CartItem> cartItems;

}