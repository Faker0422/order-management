package com.genckart.service;

import com.genckart.dto.CategoryDTO;
import java.util.List;

public interface CategoryService {
    List<CategoryDTO> getAllCategories();
    CategoryDTO createCategory(CategoryDTO categoryDTO);
    CategoryDTO updateCategory(int id, CategoryDTO categoryDTO);
    void deleteCategory(int id);
    CategoryDTO getByCategoryId(int id);
    CategoryDTO getByCategoryName(String name);
}
