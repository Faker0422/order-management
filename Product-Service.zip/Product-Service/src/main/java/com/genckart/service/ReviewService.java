package com.genckart.service;

import com.genckart.dto.ReviewDTO;
import java.util.List;

public interface ReviewService {
    List<ReviewDTO> getAllReviews();
    List<ReviewDTO> getReviewsByProductId(Integer productId);
    List<ReviewDTO> getReviewsByUserId(Integer userId);
    ReviewDTO createReview(ReviewDTO reviewDTO);
    void deleteReview(Integer reviewId);
}
