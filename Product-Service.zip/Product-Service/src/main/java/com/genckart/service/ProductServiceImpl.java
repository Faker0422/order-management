package com.genckart.service;

import com.genckart.dto.ProductDTO;
import com.genckart.dto.ReviewDTO;
import com.genckart.entity.Category;
import com.genckart.entity.Product;
import com.genckart.exception.ResourceNotFoundException;
import com.genckart.repository.CategoryRepository;
import com.genckart.repository.ProductRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public List<ProductDTO> getAllProducts() {
        return productRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public ProductDTO getProductById(Integer id) {
        Product product = productRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        return convertToDTO(product);
    }

    @Override
    public List<ProductDTO> getProductsByName(String name) {
        return productRepository.findByNameContaining(name).stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public ProductDTO addProduct(ProductDTO productDTO) {
        Product product = convertToEntity(productDTO);
        product = productRepository.save(product);
        return convertToDTO(product);
    }

    @Override
    public ProductDTO updateProductDetails(Integer id, ProductDTO productDTO) {
        Product product = productRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        // Update product details
        product.setName(productDTO.getName());
        product.setNewPrice(productDTO.getNewPrice());
        product.setOldPrice(productDTO.getOldPrice());
        product.setGender(productDTO.getGender());
        product.setQuantity(productDTO.getQuantity());
        product.setRating(productDTO.getRating());
        product.setBrand(productDTO.getBrand());
        product.setPopularity(productDTO.getPopularity());
        product.setColor(productDTO.getColor());
        product.setDescription(productDTO.getDescription());
        product.setImage1(productDTO.getImage1());
        product.setImage2(productDTO.getImage2());
        product.setImage3(productDTO.getImage3());
        product.setDiscount(productDTO.getDiscount());
        product.setHighlightShippingFee(productDTO.getHighlightShippingFee());

        Category category = categoryRepository.findByName(productDTO.getCategoryName())
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));
        product.setCategory(category);

        product = productRepository.save(product);
        return convertToDTO(product);
    }

    @Override
    @Transactional
    public void deleteProduct(Integer id) {
        productRepository.deleteById(id);
    }

    @Override
    public List<ProductDTO> getRelatedProducts(Integer productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        Integer categoryId = product.getCategory().getCategoryId();
        return productRepository.findRelatedProductsByCategory(categoryId, productId)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

//    @Override
//    public List<ProductDTO> getRelatedProductsByName(String name, Integer productId) {
//        Product product = productRepository.findById(productId)
//                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));
//        String pattern = generatePattern(product.getName());
//        return productRepository.findRelatedProductsByPattern(pattern, productId)
//                .stream()
//                .map(this::convertToDTO)
//                .collect(Collectors.toList());
//    }

    private String generatePattern(String name) {
        // Generate a pattern to match more than 4 consecutive letters
        StringBuilder pattern = new StringBuilder();
        for (int i = 0; i <= name.length() - 4; i++) {
            pattern.append(name.substring(i, i + 4)).append("%");
        }
        return pattern.toString();
    }

    @Override
    public List<ProductDTO> getRelatedProductsByCategoryName(String categoryName) {
        Category category = categoryRepository.findByName(categoryName)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));
        return productRepository.findByCategory(category).stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public ProductDTO getProductWithReviewsAndRelatedProducts(Integer productId) {
        Product product = productRepository.findProductWithReviewsAndRelatedProducts(productId);
        return convertToDTOWithDetails(product);
    }

    private ProductDTO convertToDTO(Product product) {
        ProductDTO productDTO = new ProductDTO();
        // Set fields from product to productDTO
        productDTO.setProductId(product.getProductId());
        productDTO.setName(product.getName());
        productDTO.setNewPrice(product.getNewPrice());
        productDTO.setOldPrice(product.getOldPrice());
        productDTO.setGender(product.getGender());
        productDTO.setQuantity(product.getQuantity());
        productDTO.setRating(product.getRating());
        productDTO.setBrand(product.getBrand());
        productDTO.setPopularity(product.getPopularity());
        productDTO.setColor(product.getColor());
        productDTO.setDescription(product.getDescription());
        productDTO.setImage1(product.getImage1());
        productDTO.setImage2(product.getImage2());
        productDTO.setImage3(product.getImage3());
        productDTO.setDiscount(product.getDiscount());
        productDTO.setHighlightShippingFee(product.getHighlightShippingFee());
        productDTO.setCategoryName(product.getCategory().getName()); // Set category name
        return productDTO;
    }

    private ProductDTO convertToDTOWithDetails(Product product) {
        ProductDTO productDTO = convertToDTO(product);

        // Set reviews
        productDTO.setReviews(product.getReviews().stream().map(review -> {
            ReviewDTO reviewDTO = new ReviewDTO();
            reviewDTO.setReviewId(review.getReviewId());
            reviewDTO.setUserId(review.getUserId());
            reviewDTO.setRating(review.getRating());
            reviewDTO.setReviewText(review.getReviewText());
            reviewDTO.setCreatedAt(review.getCreatedAt());
            return reviewDTO;
        }).collect(Collectors.toList()));

        // Set related products
        productDTO.setRelatedProducts(product.getRelatedProducts().stream().map(relatedProduct -> {
            ProductDTO relatedProductDTO = new ProductDTO();
            relatedProductDTO.setProductId(relatedProduct.getRelatedProducts().getProductId());
            relatedProductDTO.setName(relatedProduct.getRelatedProducts().getName());
            relatedProductDTO.setNewPrice(relatedProduct.getRelatedProducts().getNewPrice());
            relatedProductDTO.setOldPrice(relatedProduct.getRelatedProducts().getOldPrice());
            relatedProductDTO.setGender(relatedProduct.getRelatedProducts().getGender());
            relatedProductDTO.setQuantity(relatedProduct.getRelatedProducts().getQuantity());
            relatedProductDTO.setRating(relatedProduct.getRelatedProducts().getRating());
            relatedProductDTO.setBrand(relatedProduct.getRelatedProducts().getBrand());
            relatedProductDTO.setPopularity(relatedProduct.getRelatedProducts().getPopularity());
            relatedProductDTO.setColor(relatedProduct.getRelatedProducts().getColor());
            relatedProductDTO.setDescription(relatedProduct.getRelatedProducts().getDescription());
            relatedProductDTO.setImage1(relatedProduct.getRelatedProducts().getImage1());
            relatedProductDTO.setImage2(relatedProduct.getRelatedProducts().getImage2());
            relatedProductDTO.setImage3(relatedProduct.getRelatedProducts().getImage3());
            relatedProductDTO.setDiscount(relatedProduct.getRelatedProducts().getDiscount());
            relatedProductDTO.setHighlightShippingFee(relatedProduct.getRelatedProducts().getHighlightShippingFee());
            relatedProductDTO.setCategoryName(relatedProduct.getRelatedProducts().getCategory().getName());
            return relatedProductDTO;
        }).collect(Collectors.toList()));

        return productDTO;
    }

    private Product convertToEntity(ProductDTO productDTO) {
        Product product = new Product();
        // Set fields from productDTO to product
        product.setName(productDTO.getName());
        product.setNewPrice(productDTO.getNewPrice());
        product.setOldPrice(productDTO.getOldPrice());
        product.setGender(productDTO.getGender());
        product.setQuantity(productDTO.getQuantity());
        product.setRating(productDTO.getRating());
        product.setBrand(productDTO.getBrand());
        product.setPopularity(productDTO.getPopularity());
        product.setColor(productDTO.getColor());
        product.setDescription(productDTO.getDescription());
        product.setImage1(productDTO.getImage1());
        product.setImage2(productDTO.getImage2());
        product.setImage3(productDTO.getImage3());
        product.setDiscount(productDTO.getDiscount());
        product.setHighlightShippingFee(productDTO.getHighlightShippingFee());

        Category category = categoryRepository.findByName(productDTO.getCategoryName())
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));
        product.setCategory(category);

        return product;
    }
}