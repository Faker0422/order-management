package com.genckart.service;

import com.genckart.dto.ProductDTO;
import java.util.List;

public interface ProductService {
    List<ProductDTO> getAllProducts();
    ProductDTO getProductById(Integer id);
    List<ProductDTO> getProductsByName(String name);
    ProductDTO addProduct(ProductDTO productDTO);
    ProductDTO updateProductDetails(Integer id, ProductDTO productDTO);
    void deleteProduct(Integer id);
    List<ProductDTO> getRelatedProducts(Integer productId);
    //    List<ProductDTO> getRelatedProductsByName(String name, Integer productId);
    List<ProductDTO> getRelatedProductsByCategoryName(String categoryName);
    ProductDTO getProductWithReviewsAndRelatedProducts(Integer productId);
}