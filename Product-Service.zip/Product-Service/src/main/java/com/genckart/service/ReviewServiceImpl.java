package com.genckart.service;
import com.genckart.clients.UserClient;
import com.genckart.dto.ReviewDTO;
import com.genckart.dto.UserDTO;
import com.genckart.entity.Product;
import com.genckart.entity.Review;
import com.genckart.repository.ProductRepository;
import com.genckart.repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReviewServiceImpl implements ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserClient userClient;

    @Override
    public List<ReviewDTO> getAllReviews() {
        return reviewRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public List<ReviewDTO> getReviewsByProductId(Integer productId) {
        return reviewRepository.findByProductProductId(productId).stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public List<ReviewDTO> getReviewsByUserId(Integer userId) {
        return reviewRepository.findByUserId(userId).stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public ReviewDTO createReview(ReviewDTO reviewDTO) {
        Review review = new Review();
        // Fetch user details from user profile management microservice
        ResponseEntity<UserDTO> responseEntity = userClient.getUserById(reviewDTO.getUserId());
        UserDTO userDTO = responseEntity.getBody();

        // Fetch product details
        Product product = productRepository.findById(reviewDTO.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Set fields from reviewDTO to review
        review.setRating(reviewDTO.getRating());
        review.setReviewText(reviewDTO.getReviewText());
        review.setUserId(userDTO.getUserId()); // Store userId instead of UserInfo object
        review.setProduct(product);

        review = reviewRepository.save(review);
        return convertToDTO(review, userDTO);
    }

    @Override
    public void deleteReview(Integer reviewId) {
        reviewRepository.deleteById(reviewId);
    }

    private ReviewDTO convertToDTO(Review review, UserDTO userDTO) {
        ReviewDTO reviewDTO = new ReviewDTO();
        // Set fields from review to reviewDTO
        reviewDTO.setReviewId(review.getReviewId());
        reviewDTO.setUserId(review.getUserId());
        reviewDTO.setProductId(review.getProduct().getProductId());
        reviewDTO.setRating(review.getRating());
        reviewDTO.setReviewText(review.getReviewText());
        reviewDTO.setUser(userDTO); // Include user details in the DTO
        return reviewDTO;
    }

    private ReviewDTO convertToDTO(Review review) {
        ReviewDTO reviewDTO = new ReviewDTO();
        // Set fields from review to reviewDTO
        reviewDTO.setReviewId(review.getReviewId());
        reviewDTO.setUserId(review.getUserId());
        reviewDTO.setProductId(review.getProduct().getProductId());
        reviewDTO.setRating(review.getRating());
        reviewDTO.setReviewText(review.getReviewText());
        return reviewDTO;
    }
}