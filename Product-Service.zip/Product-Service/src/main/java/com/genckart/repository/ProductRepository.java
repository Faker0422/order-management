package com.genckart.repository;
import com.genckart.entity.Category;
import com.genckart.entity.Product;

import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
public interface ProductRepository extends JpaRepository<Product, Integer> {
    List<Product> findByNameContaining(String name);

    @Query("SELECT p FROM Product p WHERE p.category.categoryId = :categoryId AND p.productId <> :productId")
    List<Product> findRelatedProductsByCategory(@Param("categoryId") Integer categoryId, @Param("productId") Integer productId);

    List<Product> findByCategory(Category category);

    @Query("SELECT p FROM Product p LEFT JOIN FETCH p.reviews LEFT JOIN FETCH p.relatedProducts WHERE p.productId = :productId")
    Product findProductWithReviewsAndRelatedProducts(@Param("productId") Integer productId);

//    @Query("SELECT p FROM Product p WHERE p.name LIKE %:pattern% AND p.productId <> :productId")
//    List<Product> findRelatedProductsByPattern(@Param("pattern") String pattern, @Param("productId") Integer productId);
}