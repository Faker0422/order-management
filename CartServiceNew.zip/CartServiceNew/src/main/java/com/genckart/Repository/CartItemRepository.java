package com.genckart.Repository;

import com.genckart.Entity.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CartItemRepository extends JpaRepository<CartItem, Integer> {
    List<CartItem> findByUserId(Integer userId);
    List<CartItem> findByUserIdAndProductId(Integer userId, Integer productId);
    CartItem findByUserIdAndCartItemId(Integer userId, Integer cartItemId);
    List<CartItem> findByCart_CartId(Integer cartId);
}
