package com.genckart.Controller;

import com.genckart.Service.CartService;
import com.genckart.dto.CartDto;
import com.genckart.dto.CartItemDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/cart")
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<CartDto>> getCartByUserId(@PathVariable Integer userId) {
        List<CartDto> cart = cartService.getCartByUserId(userId);
        return new ResponseEntity<>(cart, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<CartItemDto> addItemToCart(@RequestBody CartItemDto cartItemDto) {
        CartItemDto addedItem = cartService.addItemToCart(cartItemDto);
        return new ResponseEntity<>(addedItem, HttpStatus.CREATED);
    }

    @PutMapping("/update/{userId}")
    public ResponseEntity<CartItemDto> updateItemToCart(@PathVariable Integer userId, @RequestBody CartItemDto cartItemDto) {
        CartItemDto updatedItem = cartService.updateItemToCart(userId, cartItemDto);
        return new ResponseEntity<>(updatedItem, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{userId}/{cartItemId}")
    public ResponseEntity<Void> deleteCartItemById(@PathVariable Integer userId, @PathVariable Integer cartItemId) {
        cartService.deleteCartItemById(userId, cartItemId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @DeleteMapping("/clear/{userId}")
    public ResponseEntity<Void> clearCart(@PathVariable Integer userId) {
        cartService.clearCart(userId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/isEmpty/{userId}")
    public ResponseEntity<Boolean> isCartEmpty(@PathVariable Integer userId) {
        boolean isEmpty = cartService.isCartEmpty(userId);
        return new ResponseEntity<>(isEmpty, HttpStatus.OK);
    }

    @GetMapping("/cart-items/{cartId}")
    public ResponseEntity<List<CartItemDto>> getCartItemsByCartId(@PathVariable Integer cartId) {
        List<CartItemDto> cartItems = cartService.getCartItemsByCartId(cartId);
        return ResponseEntity.ok(cartItems);
    }
}