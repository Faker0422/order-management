package com.genckart.dto;

import lombok.Data;

@Data
public class ProductDto {
    private Integer productId;
    private String name;
    private double newPrice;
    private int quantity;
    private String brand;
    private String color;
    private String description;
    private String image1;
    private double highlightShippingFee;
}