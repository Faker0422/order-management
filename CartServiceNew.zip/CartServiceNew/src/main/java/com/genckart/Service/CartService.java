package com.genckart.Service;

import com.genckart.dto.CartDto;
import com.genckart.dto.CartItemDto;

import java.util.List;

public interface CartService {
    List<CartDto> getCartByUserId(Integer userId);
    CartItemDto addItemToCart(CartItemDto cartItemDto);
    CartItemDto updateItemToCart(Integer userId, CartItemDto cartItemDto);
    void deleteCartItemById(Integer userId, Integer cartItemId);
    void clearCart(Integer userId);
    boolean isCartEmpty(Integer userId);
    List<CartItemDto> getCartItemsByCartId(Integer cartId);
}
