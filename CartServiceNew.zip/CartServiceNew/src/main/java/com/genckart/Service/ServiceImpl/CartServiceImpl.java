package com.genckart.Service.ServiceImpl;

import com.genckart.Client.ProductClient;
import com.genckart.Client.UserClient;
import com.genckart.Entity.Cart;
import com.genckart.Entity.CartItem;
import com.genckart.Repository.CartItemRepository;
import com.genckart.Repository.CartRepository;
import com.genckart.Service.CartService;
import com.genckart.dto.CartDto;
import com.genckart.dto.CartItemDto;
import com.genckart.dto.ProductDto;
import com.genckart.dto.UserDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CartServiceImpl implements CartService {

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final ProductClient productServiceClient;
    private final UserClient userServiceClient;

    @Override
    public List<CartDto> getCartByUserId(Integer userId) {
        try {
            // Fetch user details
            ResponseEntity<UserDto> userResponse = userServiceClient.getUserById(userId);
            UserDto user = userResponse.getBody();
            if (user == null) {
                throw new RuntimeException("User not found");
            }

            // Fetch cart items for the user
            List<CartItemDto> cartItems = cartItemRepository.findByUserId(userId).stream()
                    .map(cartItem -> {
                        try {
                            // Fetch product details for each cart item
                            ResponseEntity<ProductDto> productResponse = productServiceClient.getProductById(cartItem.getProductId());
                            ProductDto product = productResponse.getBody();
                            if (product == null) {
                                throw new RuntimeException("Product not found");
                            }
                            CartItemDto cartItemDto = new CartItemDto();
                            cartItemDto.setCartItemId(cartItem.getCartItemId());
                            cartItemDto.setProductId(cartItem.getProductId());
                            cartItemDto.setQuantity(cartItem.getQuantity());
                            cartItemDto.setProductName(product.getName());
                            cartItemDto.setProductPrice(product.getNewPrice());
                            return cartItemDto;
                        } catch (HttpClientErrorException.NotFound e) {
                            throw new RuntimeException("Product not found with id: " + cartItem.getProductId());
                        }
                    })
                    .collect(Collectors.toList());

            // Create and return CartDto
            CartDto cartDto = new CartDto();
            cartDto.setUserId(userId);
            cartDto.setUserName(user.getName());
            cartDto.setCartItems(cartItems);
            return List.of(cartDto);
        } catch (HttpClientErrorException e) {
            throw new RuntimeException("Error fetching user or product details", e);
        }
    }

    @Override
    public CartItemDto addItemToCart(CartItemDto cartItemDto) {
        try {
            // Fetch the cart for the user
            Cart cart = (Cart) cartRepository.findByUserId(cartItemDto.getUserId())
                    .orElseThrow(() -> new RuntimeException("Cart not found for user"));

            // Convert DTO to entity
            CartItem cartItem = new CartItem();
            cartItem.setCart(cart); // Set the cart reference
            cartItem.setUserId(cartItemDto.getUserId());
            cartItem.setProductId(cartItemDto.getProductId());
            cartItem.setQuantity(cartItemDto.getQuantity());
            cartItem.setProductName(cartItemDto.getProductName());
            cartItem.setProductPrice(cartItemDto.getProductPrice());

            // Save cart item
            CartItem savedCartItem = cartItemRepository.save(cartItem);

            // Convert entity back to DTO
            cartItemDto.setCartItemId(savedCartItem.getCartItemId());
            return cartItemDto;
        } catch (Exception e) {
            throw new RuntimeException("Error adding item to cart", e);
        }
    }

    @Override
    public CartItemDto updateItemToCart(Integer userId, CartItemDto cartItemDto) {
        try {
            // Find existing cart items by userId and productId
            List<CartItem> existingCartItems = cartItemRepository.findByUserIdAndProductId(userId, cartItemDto.getProductId());

            if (existingCartItems.isEmpty()) {
                throw new RuntimeException("Cart item not found");
            }

            // Update the first cart item found (or handle multiple items as needed)
            CartItem existingCartItem = existingCartItems.get(0);
            existingCartItem.setQuantity(cartItemDto.getQuantity());

            // Save updated cart item
            CartItem updatedCartItem = cartItemRepository.save(existingCartItem);

            // Convert entity back to DTO
            cartItemDto.setCartItemId(updatedCartItem.getCartItemId());
            cartItemDto.setUserId(updatedCartItem.getUserId());
            cartItemDto.setProductId(updatedCartItem.getProductId());
            cartItemDto.setQuantity(updatedCartItem.getQuantity());

            return cartItemDto;
        } catch (Exception e) {
            throw new RuntimeException("Error updating item in cart", e);
        }
    }

    @Override
    public void deleteCartItemById(Integer userId, Integer cartItemId) {
        try {
            CartItem cartItem = cartItemRepository.findByUserIdAndCartItemId(userId, cartItemId);
            if (cartItem == null) {
                throw new RuntimeException("Cart item not found");
            }
            cartItemRepository.delete(cartItem);
        } catch (Exception e) {
            throw new RuntimeException("Error deleting cart item", e);
        }
    }

    @Override
    public void clearCart(Integer userId) {
        try {
            List<CartItem> cartItems = cartItemRepository.findByUserId(userId);
            cartItemRepository.deleteAll(cartItems);
        } catch (Exception e) {
            throw new RuntimeException("Error clearing cart", e);
        }
    }

    @Override
    public boolean isCartEmpty(Integer userId) {
        try {
            return cartItemRepository.findByUserId(userId).isEmpty();
        } catch (Exception e) {
            throw new RuntimeException("Error checking if cart is empty", e);
        }
    }

    public List<CartItemDto> getCartItemsByCartId(Integer cartId) {
        try {
            List<CartItem> cartItems = cartItemRepository.findByCart_CartId(cartId);
            return cartItems.stream()
                    .map(cartItem -> {
                        ResponseEntity<ProductDto> productResponse = productServiceClient.getProductById(cartItem.getProductId());
                        ProductDto product = productResponse.getBody();
                        if (product == null) {
                            throw new RuntimeException("Product not found");
                        }
                        CartItemDto cartItemDto = new CartItemDto();
                        cartItemDto.setCartItemId(cartItem.getCartItemId());
                        cartItemDto.setProductId(cartItem.getProductId());
                        cartItemDto.setQuantity(cartItem.getQuantity());
                        cartItemDto.setProductName(product.getName());
                        cartItemDto.setProductPrice(product.getNewPrice());
                        return cartItemDto;
                    })
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Error fetching cart items by cart ID", e);
        }
    }
}