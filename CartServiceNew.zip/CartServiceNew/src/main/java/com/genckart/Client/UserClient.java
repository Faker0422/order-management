package com.genckart.Client;

import com.genckart.dto.UserDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "User-Profile-Management-Service", url = "http://localhost:8082/user")
public interface UserClient {
    @GetMapping("/profile/{id}")
    public ResponseEntity<UserDto> getUserById(@PathVariable Integer id);

}
