package com.genckart.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class GenckartAppException extends RuntimeException{
    private final HttpStatus httpStatus;
    private final String msg;

    public  GenckartAppException(HttpStatus httpStatus,String msg){
        this.httpStatus=httpStatus;
        this.msg =msg;
    }

}
