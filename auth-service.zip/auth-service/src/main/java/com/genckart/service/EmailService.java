package com.genckart.service;

public interface EmailService {
    void sendPasswordResetEmail(String to, String resetLink);
}