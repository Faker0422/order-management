package com.genckart.service;

import com.genckart.dto.*;
import com.genckart.exception.UserNotFoundException;
import com.genckart.model.User;

import java.util.List;

public interface AuthService {
    void signup(SignupRequestDTO request);
    String login(LoginRequestDTO request);
    void forgotPassword(ForgotPasswordRequestDTO request);
    void resetPassword(ResetPasswordRequestDTO request);
    List<User> getAllUsers();
    void updateUser(UpdateUserRequestDTO request);
    User getUserByEmail(String email);
    Integer getUserIdFromToken(String token);
    UserIdResponseDTO getCurrentUserId() throws UserNotFoundException;
    AdminStatusResponseDTO isCurrentUserAdmin() throws UserNotFoundException;
}