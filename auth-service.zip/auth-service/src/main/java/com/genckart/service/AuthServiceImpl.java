package com.genckart.service;


import com.genckart.client.UserClient;
import com.genckart.dto.*;
import com.genckart.exception.UserNotFoundException;
//import com.genckart.model.Cart;
import com.genckart.model.User;

//import com.genckart.repository.CartRepository;

import com.genckart.repository.UserRepository;
import com.genckart.security.JwtTokenProvider;
import com.genckart.util.PasswordUtil;
import com.genckart.util.UserMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Slf4j
@Service
public class AuthServiceImpl implements AuthService {

    String exceptionStatement = "User not found with email: ";

    private final UserClient userClient;

    public AuthServiceImpl(
//            CartRepository cartRepository,
            EmailService emailService, UserRepository userRepository, AuthenticationManager authenticationManager, JwtTokenProvider jwtTokenProvider,UserClient userClient) {
//        this.cartRepository = cartRepository;
        this.emailService = emailService;
//        this.userRepository = userRepository;
        this.authenticationManager = authenticationManager;
        this.jwtTokenProvider = jwtTokenProvider;
        this.userRepository = userRepository;
        this.userClient = userClient;
    }

//    private final CartRepository cartRepository;
    private final EmailService emailService;
    private final UserRepository userRepository;
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;

    public void signup(SignupRequestDTO request) {
        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPhoneNumber(request.getPhoneNumber());
        user.setPasswordHash(PasswordUtil.hashPassword(request.getPassword()));
        user.setRole(request.getRole() == null ? "ROLE_USER" : request.getRole());
        userRepository.save(user);

        User userInfo = UserMapper.toUserInfo(user);

        // Create a new cart for the user
//        Cart cart = new Cart();
//        cart.setUser(userInfo);
//        cartRepository.save(cart);
    }


    public String login(LoginRequestDTO request) {
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword());
        Authentication authentication = authenticationManager.authenticate(token);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        return jwtTokenProvider.generateToken(authentication);
    }



    public void forgotPassword(ForgotPasswordRequestDTO request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new UserNotFoundException(exceptionStatement + request.getEmail()));

        String token = UUID.randomUUID().toString();
        String resetLink = "http://localhost:9090/api/auth/reset-password?token=" + token;
        emailService.sendPasswordResetEmail(user.getEmail(), resetLink);

        log.info("Password reset email sent to: " + user.getEmail());
    }

    public void resetPassword(ResetPasswordRequestDTO request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new UserNotFoundException(exceptionStatement + request.getEmail()));

        user.setPasswordHash(PasswordUtil.hashPassword(request.getNewPassword()));
        userRepository.save(user);
    }


    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public void updateUser(UpdateUserRequestDTO request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + request.getUserId()));
        if (request.getName() != null) user.setName(request.getName());
        if (request.getEmail() != null) user.setEmail(request.getEmail());
        if (request.getPhoneNumber() != null) user.setPhoneNumber(request.getPhoneNumber());
        if (request.getRole() != null) user.setRole(request.getRole());
        userRepository.save(user);
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException(exceptionStatement + email));
    }


    public Integer getUserIdFromToken(String token){
        String name = jwtTokenProvider.getUserName(token);
        log.info("User Email "+name);
        User userInfo = userRepository.findByName(name).orElseThrow(() -> new UserNotFoundException(("User not found with name: "+ name)));
        log.info("User ID "+userInfo);
        return userInfo.getUserId();
    }


    @Override
    public UserIdResponseDTO getCurrentUserId() throws UserNotFoundException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || "anonymousUser".equals(authentication.getName())) {
            throw new IllegalStateException("No authentication found in security context or user is anonymous");
        }
        String currentUserName = authentication.getName();
        log.info("Fetching user by email: {}", currentUserName);
        ResponseEntity<UserAuthDTO> userResponse = userClient.getUserByName(currentUserName);
        log.info("UserClient response: {}", userResponse);
        UserAuthDTO userInfo = userResponse.getBody();
        if (userInfo == null) {
            throw new UserNotFoundException("User not found with email: " + currentUserName);
        }
        log.info("User info retrieved: {}", userInfo);
        return new UserIdResponseDTO(userInfo.getUserId());
    }

    @Override
    public AdminStatusResponseDTO isCurrentUserAdmin() throws UserNotFoundException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || "anonymousUser".equals(authentication.getName())) {
            throw new IllegalStateException("No authentication found in security context or user is anonymous");
        }
        String currentUserName = authentication.getName();
        log.info("Fetching user by email: {}", currentUserName);
        ResponseEntity<UserAuthDTO> userResponse = userClient.getUserByName(currentUserName);
        log.info("UserClient response: {}", userResponse);
        UserAuthDTO userInfo = userResponse.getBody();
        if (userInfo == null) {
            throw new UserNotFoundException("User not found with email: " + currentUserName);
        }
        log.info("User info retrieved: {}", userInfo);
        String userRole = userInfo.getRole();
        return new AdminStatusResponseDTO(userRole.equals("ROLE_ADMIN"));
    }


}