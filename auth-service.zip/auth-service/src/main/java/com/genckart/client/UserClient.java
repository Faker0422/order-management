package com.genckart.client;

import com.genckart.dto.UserAuthDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "user-service", url = "http://localhost:8086/api/user")
public interface UserClient {

    @GetMapping("profile/email/{email}")
    ResponseEntity<UserAuthDTO> getUserByEmail(@PathVariable("email") String email);

    @GetMapping("profile/name/{name}")
    ResponseEntity<UserAuthDTO> getUserByName(@PathVariable("name") String name);
}