package com.genckart.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginResponseDTO {
    private String userId;
    private String name;
    private String email;
    private String token;
    private String tokenType="Bearer";

    public LoginResponseDTO(String userId, String name, String email, String token,String tokenType) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.token = token;
        this.tokenType = tokenType;
    }
}