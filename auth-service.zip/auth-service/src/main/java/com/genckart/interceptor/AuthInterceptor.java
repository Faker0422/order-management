package com.genckart.interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.genckart.exception.UserNotFoundException;
import com.genckart.model.User;
import com.genckart.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.HashMap;
import java.util.Map;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    private final UserRepository userRepository;

    public AuthInterceptor(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUserName = authentication.getName();
        User userInfo = userRepository.findByName(currentUserName)
                .orElseThrow(() -> new UserNotFoundException("User not found with name: " + currentUserName));
        Integer currentUserId = userInfo.getUserId();
        String userRole = userInfo.getRole();

        String requestedUserId = request.getParameter("userId");
        if (requestedUserId != null && !userRole.equals("ADMIN") && !requestedUserId.equals(currentUserId.toString())) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.setContentType("application/json");
            Map<String, String> responseMap = new HashMap<>();
            responseMap.put("error", "You are not authorized to access this data");
            ObjectMapper objectMapper = new ObjectMapper();
            response.getWriter().write(objectMapper.writeValueAsString(responseMap));
            return false;
        }

        return true;
    }
}