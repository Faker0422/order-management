package com.genckart.util;


import com.genckart.exception.UserNotFoundException;
import com.genckart.model.User;
import com.genckart.repository.UserRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Slf4j
@AllArgsConstructor
@Component
public class UserIdProvider {

    private UserRepository userRepository;

    public Integer getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUserName = authentication.getName();
        User userInfo = userRepository.findByName(currentUserName)
                .orElseThrow(() -> new UserNotFoundException("User not found with name: " + currentUserName));
        return userInfo.getUserId();
    }

    public boolean isCurrentUserAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUserName = authentication.getName();
        User userInfo = userRepository.findByName(currentUserName)
                .orElseThrow(() -> new UserNotFoundException("User not found with name: " + currentUserName));
        String userRole = userInfo.getRole();
        log.info(userRole);
        return userRole.equals("ROLE_ADMIN");
    }
}
