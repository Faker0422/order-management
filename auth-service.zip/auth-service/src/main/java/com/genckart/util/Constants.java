package com.genckart.util;


public class Constants {
    public static final String SUCCESS_MESSAGE="success";
    public static final String ERROR_MESSAGE ="error";
    private Constants(){}
}
