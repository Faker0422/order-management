package com.genckart.util;


import com.genckart.model.User;

public class UserMapper {

    private UserMapper(){}

    public static User toUserInfo(User user) {
        if (user == null) {
            return null;
        }

        User userInfo = new User();
        userInfo.setUserId(user.getUserId());
        userInfo.setName(user.getName());
        userInfo.setEmail(user.getEmail());
        userInfo.setPhoneNumber(user.getPhoneNumber());
        userInfo.setPasswordHash(user.getPasswordHash());
        userInfo.setRole(user.getRole());
        return userInfo;
    }

    public static User toUser(User userInfo) {
        if (userInfo == null) {
            return null;
        }

        User user = new User();
        user.setUserId(userInfo.getUserId());
        user.setName(userInfo.getName());
        user.setEmail(userInfo.getEmail());
        user.setPhoneNumber(userInfo.getPhoneNumber());
        user.setPasswordHash(userInfo.getPasswordHash());
        user.setRole(userInfo.getRole());
        return user;
    }
}