package com.genckart.controller;

import com.genckart.dto.*;
import com.genckart.exception.UserNotFoundException;
import com.genckart.model.User;
import com.genckart.security.JwtTokenProvider;
import com.genckart.security.TokenBlacklistService;
import com.genckart.service.AuthService;
import com.genckart.util.Constants;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final TokenBlacklistService tokenBlacklistService;

    private final AuthService authService;

    private final JwtTokenProvider jwtTokenProvider;


    @PostMapping("/signup")
    public ResponseEntity<StandardResponseDTO<String>> signup(@Valid @RequestBody SignupRequestDTO signupRequest) {
        authService.signup(signupRequest);
        StandardResponseDTO<String> response = new StandardResponseDTO<>("User registered successfully!", Constants.SUCCESS_MESSAGE, null);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/login")
    public ResponseEntity<StandardResponseDTO<LoginResponseDTO>> login(@Valid @RequestBody LoginRequestDTO loginRequest) {
        String token = authService.login(loginRequest);
        User user = authService.getUserByEmail(loginRequest.getEmail());
        LoginResponseDTO loginResponse = new LoginResponseDTO(user.getUserId().toString(), user.getName(), user.getEmail(), token,"Bearer");
        StandardResponseDTO<LoginResponseDTO> response = new StandardResponseDTO<>("Login successful!", Constants.SUCCESS_MESSAGE, loginResponse);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<StandardResponseDTO<String>> forgotPassword(@Valid @RequestBody ForgotPasswordRequestDTO request) {
        authService.forgotPassword(request);
        StandardResponseDTO<String> response = new StandardResponseDTO<>("Password reset email sent!", Constants.SUCCESS_MESSAGE, null);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/reset-password")
    public ResponseEntity<StandardResponseDTO<String>> resetPassword(@Valid @RequestBody ResetPasswordRequestDTO request) {
        authService.resetPassword(request);
        StandardResponseDTO<String> response = new StandardResponseDTO<>("Password reset successfully!", Constants.SUCCESS_MESSAGE, null);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @GetMapping("/users")
    public ResponseEntity<StandardResponseDTO<List<User>>> getAllUsers() {
        List<User> users = authService.getAllUsers();
        StandardResponseDTO<List<User>> response = new StandardResponseDTO<>("Users retrieved successfully!", "success", users);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/update-user")
    public ResponseEntity<StandardResponseDTO<String>> updateUser(@Valid @RequestBody UpdateUserRequestDTO updateUserRequest) {
        authService.updateUser(updateUserRequest);
        StandardResponseDTO<String> response = new StandardResponseDTO<>("User updated successfully!", Constants.SUCCESS_MESSAGE, null);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/logout")
    public ResponseEntity<StandardResponseDTO<String>> logout(@RequestHeader("Authorization") String token) {
        if (token != null && token.startsWith("Bearer ")) {
            String jwtToken = token.substring(7);
            tokenBlacklistService.addToBlacklist(jwtToken);
        }
        SecurityContextHolder.clearContext();

        StandardResponseDTO<String> response = new StandardResponseDTO<>();
        response.setMessage("Logged out successfully");
        response.setStatus(Constants.SUCCESS_MESSAGE);
        response.setData(null); // No specific data to return
        return ResponseEntity.ok(response);
    }

    @PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
    @GetMapping("/getnamefromtoken")
    public ResponseEntity<Integer> getUserIdFromToken(@RequestHeader("Authorization") String token) {
        String jwt = token.substring(7);
        log.info("JWT TOKEN "+jwt);
        Integer userId = authService.getUserIdFromToken(jwt);
        return ResponseEntity.ok(userId);
    }

//    @PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
    @GetMapping("/validate/{token}")
    public ResponseEntity<ValidTokenResponse> validateToken(@PathVariable String token){
        boolean valid = jwtTokenProvider.validate(token);
        ValidTokenResponse validTokenResponse = new ValidTokenResponse();
        validTokenResponse.setValid(valid);
        return ResponseEntity.ok(validTokenResponse);
    }




    @GetMapping("/current-id")
    public ResponseEntity<StandardResponseDTO<UserIdResponseDTO>> getCurrentUserId() {
        try {
            UserIdResponseDTO responseDTO = authService.getCurrentUserId();
            StandardResponseDTO<UserIdResponseDTO> response = new StandardResponseDTO<>("User ID retrieved successfully!", Constants.SUCCESS_MESSAGE, responseDTO);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (UserNotFoundException e) {
            StandardResponseDTO<UserIdResponseDTO> response = new StandardResponseDTO<>("User not found", Constants.ERROR_MESSAGE, null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (IllegalStateException e) {
            StandardResponseDTO<UserIdResponseDTO> response = new StandardResponseDTO<>("No authentication found or user is anonymous", Constants.ERROR_MESSAGE, null);
            return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/is-admin")
    public ResponseEntity<StandardResponseDTO<AdminStatusResponseDTO>> isCurrentUserAdmin() {
        try {
            AdminStatusResponseDTO responseDTO = authService.isCurrentUserAdmin();
            StandardResponseDTO<AdminStatusResponseDTO> response = new StandardResponseDTO<>("Admin status retrieved successfully!", Constants.SUCCESS_MESSAGE, responseDTO);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (UserNotFoundException e) {
            StandardResponseDTO<AdminStatusResponseDTO> response = new StandardResponseDTO<>("User not found", Constants.ERROR_MESSAGE, null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (IllegalStateException e) {
            StandardResponseDTO<AdminStatusResponseDTO> response = new StandardResponseDTO<>("No authentication found or user is anonymous", Constants.ERROR_MESSAGE, null);
            return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
        }
    }


}