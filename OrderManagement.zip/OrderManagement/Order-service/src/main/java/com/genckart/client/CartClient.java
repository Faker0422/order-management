package com.genckart.client;

import com.genckart.dto.CartDTO;
import com.genckart.dto.CartItemDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "CartService", url="http://localhost:8080/cart")
public interface CartClient {
    @GetMapping("/user/{userId}")
    ResponseEntity<CartDTO> getCartByUserId(@PathVariable("userId") Integer userId);

    @GetMapping("/cart-items/{cartId}")
    ResponseEntity<List<CartItemDTO>> getCartItemsByCartId(@PathVariable("cartId") Integer cartId);

    @DeleteMapping("/delete/{userId}/{cartItemId}")
    void deleteCartItem(@PathVariable Integer userId, @PathVariable Integer cartItemId);

    @GetMapping("/isEmpty/{userId}")
    ResponseEntity<Boolean>  isCartEmpty(@PathVariable Integer userId);
}