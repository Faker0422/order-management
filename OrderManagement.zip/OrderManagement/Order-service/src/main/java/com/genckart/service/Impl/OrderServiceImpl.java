package com.genckart.service.Impl;

import com.genckart.client.CartClient;
import com.genckart.client.ProductClient;
import com.genckart.client.UserIdProviderClient;
import com.genckart.dto.*;
import com.genckart.exception.OrderNotFoundException;
import com.genckart.exception.UserNotAuthorizedException;
import com.genckart.model.*;
import com.genckart.repository.*;
import com.genckart.service.OrderService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@AllArgsConstructor
@Service
public class OrderServiceImpl implements OrderService {
    private final OrderRepository orderRepository;
    private final OrderMapper orderMapper;
    private final OrderItemRepository orderItemRepository;
    private final UserIdProviderClient userIdProviderClient;
    private final CartClient cartClient;
    private final ProductClient productClient;



    @Override
    public OrderDTO createCustomOrder(OrderDTO orderDTO) {
        ResponseEntity<Integer> response = userIdProviderClient.getCurrentUserId();
        Integer currentUserId=response.getBody();
        if (orderDTO.getUserId() == null || orderDTO.getUserId() == 0) {
            orderDTO.setUserId(currentUserId);
        }

        Order order = orderMapper.toEntity(orderDTO);
        Order savedOrder = orderRepository.save(order);

        for (OrderItemDTO orderItemDTO : orderDTO.getOrderItems()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(savedOrder);
            ResponseEntity<ProductDTO> product = productClient.getProductById(orderItemDTO.getProductId());
            if (product == null) {
                throw new IllegalArgumentException("Invalid product ID");
            }
            orderItem.setQuantity(orderItemDTO.getQuantity());
            orderItem.setPrice(orderItemDTO.getPrice());
            orderItemRepository.save(orderItem);
        }

        return orderMapper.toDTO(savedOrder);
    }

    @Override
    public OrderDTO createOrder(OrderDTO orderDTO) {
        ResponseEntity<Integer> response = userIdProviderClient.getCurrentUserId();
        Integer currentUserId=response.getBody();
        log.info("Current user{}", currentUserId);
        ResponseEntity<CartDTO> cartResponse = cartClient.getCartByUserId(currentUserId);
        CartDTO cart = cartResponse.getBody();
        if (cart == null) {
            throw new IllegalStateException("Cart not found");
        }
        ResponseEntity<List<CartItemDTO>> cartItemsResponse = cartClient.getCartItemsByCartId(cart.getCartId());
        List<CartItemDTO> cartItems = cartItemsResponse.getBody();
        if (cartItems == null || cartItems.isEmpty()) {
            throw new IllegalStateException("Cart is empty");
        }
        log.info(cartItems.toString());

        if (cartItems.isEmpty()) {
            throw new IllegalStateException("Cart is empty");
        }

        if (orderDTO.getUserId() == null || orderDTO.getUserId() == 0) {
            orderDTO.setUserId(currentUserId);
        }

        Order order = orderMapper.toEntity(orderDTO);
        Order savedOrder = orderRepository.save(order);

        for (CartItemDTO cartItem : cartItems) {
            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(savedOrder);
            orderItem.setProductId(cartItem.getProductId());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItemRepository.save(orderItem);
            cartClient.deleteCartItem(orderDTO.getUserId(),cartItem.getCartItemId());
        }

        return orderMapper.toDTO(savedOrder);
    }

    @Override
    public List<OrderDTO> getAllOrders() {
        ResponseEntity<Integer> response = userIdProviderClient.getCurrentUserId();
        Integer currentUserId=response.getBody();
        ResponseEntity<Boolean> adminResponse = userIdProviderClient.isCurrentUserAdmin();
        boolean isAdmin=adminResponse.getBody();
        return orderRepository.findAll().stream()
                .filter(order -> isAdmin || order.getUserId().equals(currentUserId))
                .map(order -> {
                    OrderDTO orderDTO = orderMapper.toDTO(order);
                    List<OrderItem> orderItems = orderItemRepository.findByOrderOrderId(order.getOrderId());
                    orderDTO.setOrderItems(orderItems.stream().map(orderMapper::toDTO).collect(Collectors.toList()));
                    return orderDTO;
                })
                .collect(Collectors.toList());
    }

    @Override
    public OrderDTO getOrderById(Integer orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found"));
        ResponseEntity<Integer> response = userIdProviderClient.getCurrentUserId();
        Integer currentUserId=response.getBody();
        ResponseEntity<Boolean> adminResponse = userIdProviderClient.isCurrentUserAdmin();
        boolean isAdmin=adminResponse.getBody();

        if (!isAdmin && !order.getUserId().equals(currentUserId)) {
            throw new UserNotAuthorizedException("You do not have access to this order");
        }

        OrderDTO orderDTO = orderMapper.toDTO(order);
        List<OrderItem> orderItems = orderItemRepository.findByOrderOrderId(orderId);
        orderDTO.setOrderItems(orderItems.stream().map(orderMapper::toDTO).collect(Collectors.toList()));
        return orderDTO;
    }

    @Override
    public void deleteOrder(Integer orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found"));
        ResponseEntity<Integer> response = userIdProviderClient.getCurrentUserId();
        Integer currentUserId=response.getBody();
        ResponseEntity<Boolean> adminResponse = userIdProviderClient.isCurrentUserAdmin();
        boolean isAdmin=adminResponse.getBody();

        if (!isAdmin && !order.getUserId().equals(currentUserId)) {
            throw new UserNotAuthorizedException("You do not have access to delete this order");
        }

        orderRepository.deleteById(orderId);
    }
}