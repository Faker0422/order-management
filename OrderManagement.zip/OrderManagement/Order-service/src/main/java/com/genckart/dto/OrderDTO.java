package com.genckart.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class OrderDTO {

    private Integer userId;

    private Integer orderId;

    @NotNull
    @DecimalMin("0.0")
    private BigDecimal totalPrice;

    @NotBlank
    private String status;

    private List<OrderItemDTO> orderItems;
}