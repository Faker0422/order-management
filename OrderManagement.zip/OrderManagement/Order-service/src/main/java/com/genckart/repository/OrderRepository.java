package com.genckart.repository;

import com.genckart.dto.CartDTO;
import com.genckart.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, Integer> {
    Optional<CartDTO> findByUserId(@Param("userId") Integer userId);
}