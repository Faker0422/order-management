package com.genckart.controller;

import com.genckart.client.CartClient;
import com.genckart.client.UserIdProviderClient;
import com.genckart.dto.OrderDTO;
import com.genckart.dto.StandardResponseDTO;
import com.genckart.service.OrderService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final OrderService orderService;
    private final CartClient cartClient;
    private final UserIdProviderClient userIdProviderClient;


    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    @PostMapping("/create")
    public ResponseEntity<OrderDTO> createCustomOrder(@Valid @RequestBody OrderDTO orderDTO) {
        OrderDTO createdOrder = orderService.createCustomOrder(orderDTO);
        return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);
    }

    @PostMapping
    public ResponseEntity<OrderDTO> createOrder(@RequestBody OrderDTO orderDTO) {
        ResponseEntity<Integer> response = userIdProviderClient.getCurrentUserId();
        Integer currentUserId=response.getBody();
        if (cartClient.isCartEmpty(orderDTO.getUserId()).getBody()) {
            return ResponseEntity.badRequest().body(null);
        }
        OrderDTO createdOrder = orderService.createOrder(orderDTO);
        return ResponseEntity.ok(createdOrder);
    }

    @GetMapping
    public ResponseEntity<List<OrderDTO>> getAllOrders() {
        List<OrderDTO> orders = orderService.getAllOrders();
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<OrderDTO> getOrderById(@PathVariable Integer orderId) {
        OrderDTO order = orderService.getOrderById(orderId);
        return ResponseEntity.ok(order);
    }

    @DeleteMapping("/{orderId}")
    public ResponseEntity<StandardResponseDTO<String>> deleteOrder(@PathVariable Integer orderId) {
        orderService.deleteOrder(orderId);

        StandardResponseDTO<String> response = new StandardResponseDTO<>();
        response.setMessage("Deleted successfully");
        response.setStatus("success");
        response.setData(null);

        return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
    }
}