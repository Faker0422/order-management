package com.genckart.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class CartDTO {

    private Integer cartId;
    private int userId;
    private int productId;
    private int quantity;
    private LocalDateTime addedAt;
    private String userName;
    private List<CartItemDTO> cartItems;
}
