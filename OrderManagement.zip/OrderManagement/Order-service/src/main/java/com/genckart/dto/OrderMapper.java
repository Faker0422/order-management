package com.genckart.dto;

import com.genckart.client.ProductClient;
import com.genckart.client.UserClient;
import com.genckart.exception.OrderNotFoundException;
import com.genckart.model.*;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@AllArgsConstructor
@Component
public class OrderMapper {

    private final UserClient userClient;
    private final ProductClient productClient;


    public Order toEntity(OrderDTO orderDTO) {
        Order order = new Order();
        ResponseEntity<UserDTO> userResponse = userClient.getUserById(orderDTO.getUserId());
        UserDTO userDTO = userResponse.getBody();
        if (userDTO == null) {
            throw new OrderNotFoundException("User not found");
        }
        order.setUserId(orderDTO.getUserId());
        order.setTotalPrice(orderDTO.getTotalPrice());
        order.setStatus(orderDTO.getStatus());

        List<OrderItem> orderItems = orderDTO.getOrderItems().stream().map(this::toEntity).collect(Collectors.toList());
        orderItems.forEach(orderItem -> orderItem.setOrder(order)); // Link order items to the order
        order.setOrderItems(orderItems);

        return order;
    }

    public OrderItem toEntity(OrderItemDTO orderItemDTO) {
        OrderItem orderItem = new OrderItem();
        ResponseEntity<ProductDTO> response = productClient.getProductById(orderItemDTO.getProductId());
        ProductDTO productDTO = Optional.ofNullable(response.getBody())
                .orElseThrow(() -> new OrderNotFoundException("Product not found"));

        orderItem.setProductId(productDTO.getProductId());
        orderItem.setQuantity(orderItemDTO.getQuantity());
        orderItem.setPrice(orderItemDTO.getPrice());

        return orderItem;
    }

    public OrderDTO toDTO(Order order) {
        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setUserId(order.getUserId());
        orderDTO.setOrderId(order.getOrderId());
        orderDTO.setTotalPrice(order.getTotalPrice());
        orderDTO.setStatus(order.getStatus());

        List<OrderItemDTO> orderItemDTOs = order.getOrderItems().stream().map(this::toDTO).collect(Collectors.toList());
        orderDTO.setOrderItems(orderItemDTOs);

        return orderDTO;
    }

    public OrderItemDTO toDTO(OrderItem orderItem) {
        OrderItemDTO orderItemDTO = new OrderItemDTO();
        orderItemDTO.setProductId(orderItem.getProductId());
        orderItemDTO.setQuantity(orderItem.getQuantity());
        orderItemDTO.setPrice(orderItem.getPrice());

        return orderItemDTO;
    }
}