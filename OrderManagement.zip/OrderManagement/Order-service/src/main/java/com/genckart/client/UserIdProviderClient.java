package com.genckart.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(name = "auth-service", url = "http://localhost:9090/api/auth")
public interface UserIdProviderClient {

    @GetMapping("/current-id")
    ResponseEntity<Integer> getCurrentUserId();

    @GetMapping("/is-admin")
    ResponseEntity<Boolean> isCurrentUserAdmin();
}