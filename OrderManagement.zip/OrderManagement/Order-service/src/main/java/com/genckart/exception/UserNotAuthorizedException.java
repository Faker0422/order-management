package com.genckart.exception;

public class UserNotAuthorizedException extends RuntimeException{
    public UserNotAuthorizedException(String msg){
        super(msg);
    }
}
